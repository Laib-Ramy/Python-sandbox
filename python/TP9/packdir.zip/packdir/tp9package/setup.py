from setuptools import setup

setup(name='tp9package',
      version='0.1',
      description='An example package',
      author='Toto',
      author_email='toto@example.com',
      license='MIT',
      packages=['tp9package'],
      zip_safe=False)