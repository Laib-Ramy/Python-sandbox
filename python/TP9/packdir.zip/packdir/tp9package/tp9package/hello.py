def hello():
    print("Hello, world")

def boo():
    print("Boo!")