R = [["I", "V"], ["X", "L"], ["C", "D"], ["M", "V̅"],
     ["X̅", "L̅"], ["C̅", "D̅"], ["M̅"]]


def to_roman(number):
    pass