import unittest
from cryptarithme import set_uppercase, set_tokens, parse_equation


class TestSetUppercase(unittest.TestCase):
    def test1(self):
        actual = set_uppercase("3 * MOT = TOM - 1")
        expected = {'M', 'O', 'T'}
        self.assertEqual(actual, expected)

    def test2(self):
        actual = set_uppercase('THREE + TWO**2 = SEVEN')
        expected = {'E', 'H', 'N', 'O', 'R', 'S', 'T', 'V', 'W'}
        self.assertEqual(actual, expected)

    def test3(self):
        actual = set_uppercase('HUIT + HUIT = SEIZE')
        expected = {'E', 'H', 'I', 'S', 'T', 'U', 'Z'}
        self.assertEqual(actual, expected)

    def test4(self):
        actual = set_uppercase('UN + UN**2 = DEUX')
        expected = {'D', 'E', 'N', 'U', 'X'}
        self.assertEqual(actual, expected)

    def test5(self):
        actual = set_uppercase('4*DAME = CARRE')
        expected = {'A', 'C', 'D', 'E', 'M', 'R'}
        self.assertEqual(actual, expected)


class TestSetTokens(unittest.TestCase):
    def test1(self):
        actual = set_tokens("3 * MOT = TOM - 1")
        expected = {'MOT', 'TOM'}
        self.assertEqual(actual, expected)

    def test2(self):
        actual = set_tokens('THREE + TWO**2 = SEVEN')
        expected = {'SEVEN', 'THREE', 'TWO'}
        self.assertEqual(actual, expected)

    def test3(self):
        actual = set_tokens('HUIT + HUIT = SEIZE')
        expected = {'HUIT', 'SEIZE'}
        self.assertEqual(actual, expected)

    def test4(self):
        actual = set_tokens('UN + UN**2 = DEUX')
        expected = {'DEUX', 'UN'}
        self.assertEqual(actual, expected)

    def test5(self):
        actual = set_tokens('4*DAME = CARRE')
        expected = {'CARRE', 'DAME'}
        self.assertEqual(actual, expected)


class TestParseEquation(unittest.TestCase):
    def test1(self):
        (tokens, eq) = parse_equation("X**2 + Y**2 = Z**2")
        expected_set_tokens = {'X', 'Y', 'Z'}
        self.assertEqual(set(tokens), expected_set_tokens)

    def test2(self):
        (tokens, eq) = parse_equation("X**2 + Y**2 = Z**2")
        self.assertTrue(eq(X=3, Y=4, Z=5))

    def test3(self):
        (tokens, eq) = parse_equation("X**2 + Y**2 = Z**2")
        self.assertTrue(eq(X=5, Y=12, Z=13))

    def test4(self):
        (tokens, eq) = parse_equation("X**2 + Y**2 = Z**2")
        self.assertFalse(eq(X=1, Y=2, Z=3))

    def test5(self):
        (tokens, eq) = parse_equation("4*DAME = CARRE")
        self.assertTrue(eq(DAME=4970, CARRE=19880))

if __name__ == "__main__":
    unittest.main()
