import re
from itertools import permutations

def set_uppercase(s):
    pass

def set_tokens(s):
    pass

def parse_equation(s):
    pass

def solutions(s):
    pass
