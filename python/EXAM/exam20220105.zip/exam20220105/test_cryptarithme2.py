import unittest
from cryptarithme import solutions

class TestIntegral(unittest.TestCase):
    def test1(self):
        actual=set(solutions("3 * MOT = TOM - 1"))
        expected={"3 * 247 = 742 - 1"}
        self.assertEqual(actual, expected)

    def test2(self):
        actual=set(solutions("7*DAYS = WEEK"))
        expected={'7*1048 = 7336', '7*1207 = 8449'}
        self.assertEqual(actual, expected)

    def test3(self):
        actual=set(solutions("12*MOIS = ANNEE"))
        expected={'12*1674 = 20088', '12*5187 = 62244'}
        self.assertEqual(actual, expected)

    def test4(self):
        actual=set(solutions("UN + UN**2 = DEUX"))
        expected={'86 + 86**2 = 7482'}
        self.assertEqual(actual, expected)

    def test5(self):
        actual=set(solutions("4*DAME = CARRE"))
        expected={'4*4970 = 19880'}
        self.assertEqual(actual, expected)

    def test6(self):
        actual=set(solutions("HUIT + HUIT = SEIZE"))
        expected={'9254 + 9254 = 18508', '8253 + 8253 = 16506'}
        self.assertEqual(actual, expected)

if __name__=="__main__":
    unittest.main()