import unittest

from roman import to_roman

D1 = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 9: "IX"}
D2 = {27: "XXVII", 48: "XLVIII", 59: "LIX", 93: "XCIII"}
D3 = {141: "CXLI", 163: "CLXIII", 402: "CDII", 575: "DLXXV", 911: "CMXI"}
D4 = {1024: "MXXIV", 1703: "MDCCIII",
      1991: "MCMXCI", 2017: "MMXVII", 3000: "MMM"}
D5 = {12345: 'X̅MMCCCXLV', 23456: 'X̅X̅MMMCDLVI', 45678: 'X̅L̅V̅DCLXXVIII',
      67891: 'L̅X̅V̅MMDCCCXCI', 91234: 'X̅C̅MCCXXXIV'}
D6 = {123456: 'C̅X̅X̅MMMCDLVI', 234567: 'C̅C̅X̅X̅X̅MV̅DLXVII',
      456789: 'C̅D̅L̅V̅MDCCLXXXIX', 987654: 'C̅M̅L̅X̅X̅X̅V̅MMDCLIV'}


class TestRoman(unittest.TestCase):
    def test1(self):
        for k, v in D1.items():
            self.assertEqual(to_roman(k), v)

    def test2(self):
        for k, v in D2.items():
            self.assertEqual(to_roman(k), v)

    def test3(self):
        for k, v in D3.items():
            self.assertEqual(to_roman(k), v)

    def test4(self):
        for k, v in D4.items():
            self.assertEqual(to_roman(k), v)

    def test5(self):
        for k, v in D5.items():
            self.assertEqual(to_roman(k), v)

    def test6(self):
        for k, v in D6.items():
            self.assertEqual(to_roman(k), v)

if __name__ == "__main__":
    unittest.main()
