from itertools import combinations

def move_before(l, i):
    pass

def move_after(l, i):
    pass

def count_misordered(l):
    pass
