from django.urls import path
from . import views

urlpatterns = [
    path('', views.frise, name = "frise"),
    path('move_up', views.move_up, name="move_up"),
    path('move_down', views.move_down, name="move_down"),
    path('check_answer', views.check_answer, name="check_answer"),
]