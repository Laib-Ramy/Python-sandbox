from django.shortcuts import render
from .models import Event
from .utility import move_before, move_after, count_misordered
import random


def frise(request):
    events = list(Event.objects.all())
    quiz = random.sample(events, 10)
    questions = [{'year': q.year, 'event': q.event} for q in quiz]
    request.session['quiz'] = questions
    return render(request, "chrono/frise.html", {'questions': questions, 'done': False})


def move_up(request):
    questions = request.session['quiz']
    # Complétez le code
    return render(request, "chrono/frise.html", {'questions': questions, 'done': False})


def move_down(request):
    questions = request.session['quiz']
    # Complétez le code
    return render(request, "chrono/frise.html", {'questions': questions, 'done': False})


def check_answer(request):
    questions = request.session['quiz']
    years = [q['year'] for q in questions]
    n = len(years)
    result = 1-count_misordered(years)*4/(n*(n-1))
    result = 0 if result < 0 else result
    note = f'{20*result:.2f}'
    return render(request, "chrono/frise.html", {'questions': questions, 'done': True, 'note': note})
