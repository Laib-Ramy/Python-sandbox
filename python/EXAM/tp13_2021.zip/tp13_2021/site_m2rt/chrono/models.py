from django.db import models


class Event(models.Model):
    year=models.IntegerField()
    event=models.CharField(max_length=256)