from django.test import TestCase
from .utility import move_after, move_before, count_misordered

# Create your tests here.


class MoveTestCase(TestCase):
    def test_move_before_0(self):
        tab = [1, 2, 3, 4]
        move_before(tab, 0)
        self.assertEqual(tab, [1, 2, 3, 4])

    def test_move_before_1(self):
        tab = [1, 2, 3, 4]
        move_before(tab, 1)
        self.assertEqual(tab, [2, 1, 3, 4])

    def test_move_before_2(self):
        tab = [1, 2, 3, 4]
        move_before(tab, 2)
        self.assertEqual(tab, [1, 3, 2, 4])

    def test_move_before_3(self):
        tab = [1, 2, 3, 4]
        move_before(tab, 3)
        self.assertEqual(tab, [1, 2, 4, 3])

    def test_move_after_0(self):
        tab = [1, 2, 3, 4]
        move_after(tab, 0)
        self.assertEqual(tab, [2, 1, 3, 4])

    def test_move_after_1(self):
        tab = [1, 2, 3, 4]
        move_after(tab, 1)
        self.assertEqual(tab, [1, 3, 2, 4])

    def test_move_after_2(self):
        tab = [1, 2, 3, 4]
        move_after(tab, 2)
        self.assertEqual(tab, [1, 2, 4, 3])

    def test_move_after_3(self):
        tab = [1, 2, 3, 4]
        move_after(tab, 3)
        self.assertEqual(tab, [1, 2, 3, 4])


class MisorderedTestCase(TestCase):
    def test1(self):
        tab=[1,2,3,4,5,6]
        self.assertEqual(count_misordered(tab), 0)

    def test2(self):
        tab=[1,1,1,1,1,1]
        self.assertEqual(count_misordered(tab), 0)

    def test3(self):
        tab=[6,5,4,3,2,1]
        self.assertEqual(count_misordered(tab), 15)

    def test4(self):
        tab=[6,2,3,4,5,1]
        self.assertEqual(count_misordered(tab), 9)
        
    def test5(self):
        tab=[7,0,3,4,2,1]
        self.assertEqual(count_misordered(tab), 10)

    def test6(self):
        tab=[2,0,3,4,2,3]
        self.assertEqual(count_misordered(tab), 4)